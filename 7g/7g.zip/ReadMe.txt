To compile test:

fsharpc awariLibIncomplete.fs testname.fsx

To compile game:

fsharpc awariLibIncomplete.fs playAwari.fsx

To run any of them:

mono file.exe