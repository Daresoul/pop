
int X = [0-5]

Compile:

fsharpc img_util.fs 8iX.fsx


Run:
mone 8iX.exe 